export const mfConfig = {
  name: "color_organizer",
  exposes: {},
  shared: ["react", "react-dom"],
};

export const createArray = (length: number) => [...Array(length)];
